package com.hadeeth.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF0B3428)
private val Green2 = Color(0xFF17513C)
private val Brown = Color(0xFF65452E)
private val Gold = Color(0xFFD7B66F)
private val Cream = Color(0xFFF6F0E4)
private val Ink = Color(0xFF292B27)
private val Arabic = FontFamily(Font(R.font.amiri_regular), Font(R.font.amiri_bold, FontWeight.Bold))

data class Profile(val name:String, val adult:Boolean, val gender:String, val madhhab:String, val governorate:String)
data class Hadith(val id:String,val speaker:String,val text:String,val source:String,val group:String)
data class City(val name:String,val api:String)
private val governorates = listOf("بغداد","نينوى","البصرة","ذي قار","الأنبار","بابل","كركوك","النجف","كربلاء","ديالى","صلاح الدين","القادسية","واسط","ميسان","المثنى","دهوك","أربيل","السليمانية","حلبجة")
private val cities = listOf(City("بغداد","Baghdad"),City("نينوى / الموصل","Mosul"),City("البصرة","Basra"),City("ذي قار / الناصرية","Nasiriyah"),City("الأنبار / الرمادي","Ramadi"),City("بابل / الحلة","Hillah"),City("كركوك","Kirkuk"),City("النجف","Najaf"),City("كربلاء","Karbala"),City("ديالى / بعقوبة","Baqubah"),City("صلاح الدين / تكريت","Tikrit"),City("القادسية / الديوانية","Diwaniyah"),City("واسط / الكوت","Kut"),City("ميسان / العمارة","Amarah"),City("المثنى / السماوة","Samawah"),City("دهوك","Duhok"),City("أربيل","Erbil"),City("السليمانية","Sulaymaniyah"),City("حلبجة","Halabja"))
private val hadiths = listOf(
 Hadith("s1","رسول الله صلى الله عليه وآله","إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.","صحيح البخاري، كتاب بدء الوحي، ح 1","سني"),
 Hadith("s2","رسول الله صلى الله عليه وآله","لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.","صحيح البخاري، كتاب الإيمان، ح 13؛ صحيح مسلم، ح 45","سني"),
 Hadith("s3","رسول الله صلى الله عليه وآله","من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.","صحيح البخاري، كتاب الأدب، ح 6018؛ صحيح مسلم، ح 47","سني"),
 Hadith("s4","رسول الله صلى الله عليه وآله","يسّروا ولا تعسّروا، وبشّروا ولا تنفّروا.","صحيح البخاري، كتاب العلم، ح 69؛ صحيح مسلم، ح 1734","سني"),
 Hadith("s5","رسول الله صلى الله عليه وآله","المسلم من سلم المسلمون من لسانه ويده.","صحيح البخاري، كتاب الإيمان، ح 10؛ صحيح مسلم، ح 40","سني"),
 Hadith("s6","رسول الله صلى الله عليه وآله","الكلمة الطيبة صدقة.","صحيح البخاري، كتاب الأدب، ح 6023؛ صحيح مسلم، ح 1009","سني"),
 Hadith("s7","رسول الله صلى الله عليه وآله","لا تغضب.","صحيح البخاري، كتاب الأدب، ح 6116","سني"),
 Hadith("s8","رسول الله صلى الله عليه وآله","من لا يَرحم لا يُرحم.","صحيح البخاري، كتاب الأدب، ح 6013؛ صحيح مسلم، ح 2318","سني"),
 Hadith("j1","الإمام علي عليه السلام","قيمة كل امرئ ما يحسنه.","نهج البلاغة، الحكمة 81، بحسب ترقيم صبحي الصالح","شيعي"),
 Hadith("j2","الإمام علي عليه السلام","الناس أعداء ما جهلوا.","نهج البلاغة، الحكمة 172، بحسب ترقيم صبحي الصالح","شيعي"),
 Hadith("j3","الإمام علي عليه السلام","لسان العاقل وراء قلبه، وقلب الأحمق وراء لسانه.","نهج البلاغة، الحكمة 40، بحسب ترقيم صبحي الصالح","شيعي"),
 Hadith("j4","الإمام علي عليه السلام","إذا تم العقل نقص الكلام.","نهج البلاغة، الحكمة 71، بحسب ترقيم صبحي الصالح","شيعي"),
 Hadith("j5","الإمام علي عليه السلام","ثمرة التفريط الندامة، وثمرة الحزم السلامة.","نهج البلاغة، الحكمة 181، بحسب ترقيم صبحي الصالح","شيعي"),
 Hadith("j6","الإمام علي عليه السلام","من أصلح ما بينه وبين الله أصلح الله ما بينه وبين الناس.","نهج البلاغة، الحكمة 89، بحسب ترقيم صبحي الصالح","شيعي"),
 Hadith("j7","الإمام علي عليه السلام","الصبر صبران: صبر على ما تكره، وصبر عما تحب.","نهج البلاغة، الحكمة 55، بحسب ترقيم صبحي الصالح","شيعي"),
)

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setContent { HadeethApp() } } }

@Composable fun HadeethApp(){
 val ctx= androidx.compose.ui.platform.LocalContext.current
 val prefs= remember { ctx.getSharedPreferences("hadeeth_data",0) }
 var profile by remember { mutableStateOf(loadProfile(prefs)) }
 var page by remember { mutableStateOf("home") }; var menu by remember { mutableStateOf(false) }
 var current by remember { mutableStateOf<Hadith?>(null) }; var readIds by remember { mutableStateOf(loadIds(prefs)) }
 var fatiha by remember { mutableStateOf(false) }; var report by remember { mutableStateOf("") }; var ageChoice by remember { mutableStateOf("18+") }
 fun saveIds(ids:Set<String>){ val a=JSONArray();ids.forEach{a.put(it)};prefs.edit().putString("seen",a.toString()).apply();readIds=ids }
 fun next(){ val pool=hadiths.filter{it.group==profile?.madhhab}.filterNot{readIds.contains(it.id)}; if(pool.isNotEmpty()){val h=pool.random();current=h;saveIds(readIds+h.id)}else current=null }
 MaterialTheme(colorScheme=lightColorScheme(primary=Green2,secondary=Gold,background=Cream,surface=Cream)) {
  if(profile==null){ ProfileSetup { p -> prefs.edit().putString("profile",JSONObject().put("name",p.name).put("adult",p.adult).put("gender",p.gender).put("madhhab",p.madhhab).put("governorate",p.governorate).toString()).apply();profile=p;page="home" } }
  else Surface(Modifier.fillMaxSize(),color=Cream){ Column(Modifier.fillMaxSize()) {
   Row(Modifier.fillMaxWidth().background(Green).padding(horizontal=10.dp, vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
    if(page!="home") IconButton(onClick={page="home"}){Icon(Icons.Default.ArrowBack,null,tint=Gold)}
    Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Text("حديث",fontFamily=Arabic,color=Gold,fontSize=29.sp,fontWeight=FontWeight.Bold);Text("نورٌ من الهداية",fontFamily=Arabic,color=Color.White.copy(.75f),fontSize=12.sp)}
    Box{IconButton(onClick={menu=true}){Icon(Icons.Default.MoreVert,"القائمة",tint=Gold)};DropdownMenu(expanded=menu,onDismissRequest={menu=false},modifier=Modifier.background(Cream)){
      listOf("أحاديثي" to "history","أوقات الصلاة" to "prayer","الثواب" to "thawab","مركز المساعدة" to "help","الأدعية المقدسة" to "duas","القرآن الكريم" to "quran").forEach{(label,key)->DropdownMenuItem(text={Text(label,fontFamily=Arabic,color=Green,fontSize=18.sp)},onClick={menu=false;page=key})}
    }}
   }
   when(page){
    "home"->Home(profile!!,current,hadiths.count{it.group==profile!!.madhhab},onNext={next()},onMenu={page="history"})
    "history"->HistoryPage(hadiths.filter{readIds.contains(it.id)},readIds.size,onReset={saveIds(emptySet());current=null})
    "prayer"->PrayerPage(profile!!)
    "thawab"->ThawabPage(onFatiha={fatiha=true})
    "help"->HelpPage(report,{report=it},ctx)
    "duas"->DuasPage(profile!!)
    "quran"->QuranPage(profile!!)
    else->Home(profile!!,current,hadiths.count{it.group==profile!!.madhhab},{next()},{page="history"})
   }
  }}
  if(fatiha) Dialog(onDismissRequest={fatiha=false}){Column(Modifier.fillMaxWidth().background(Cream,RoundedCornerShape(22.dp)).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){IconButton(onClick={fatiha=false}){Icon(Icons.Default.Close,"إغلاق",tint=Brown)}};Text("سورة الفاتحة",fontFamily=Arabic,fontSize=27.sp,color=Green,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",fontFamily=Arabic,fontSize=24.sp,lineHeight=42.sp,textAlign=TextAlign.Center,color=Ink);Text("المصدر: القرآن الكريم، سورة الفاتحة (1:1–7)",fontFamily=Arabic,color=Brown,fontSize=13.sp)}}
 }
}

private fun loadProfile(p:android.content.SharedPreferences):Profile? { return try { val raw=p.getString("profile",null) ?: return null; val j=JSONObject(raw); Profile(j.getString("name"),j.getBoolean("adult"),j.getString("gender"),j.getString("madhhab"),j.getString("governorate")) } catch(_:Exception) { null } }
private fun loadIds(p:android.content.SharedPreferences):Set<String> = try{val a=JSONArray(p.getString("seen","[]"));(0 until a.length()).map{a.getString(it)}.toSet()}catch(_:Exception){emptySet()}

@Composable private fun ProfileSetup(onSave:(Profile)->Unit){var name by remember{mutableStateOf("")};var age by remember{mutableStateOf("18+")};var gender by remember{mutableStateOf("ذكر")};var madhhab by remember{mutableStateOf("شيعي")};var city by remember{mutableStateOf("بغداد")};var cityMenu by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().background(Green).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("حديث",fontFamily=Arabic,fontSize=48.sp,color=Gold,fontWeight=FontWeight.Bold);Text("أنشئ ملفك الأول",fontFamily=Arabic,fontSize=25.sp,color=Color.White);Text("حتى نعرض لك المحتوى والمواقيت المناسبة لاختياراتك",fontFamily=Arabic,color=Color.White.copy(.8f),textAlign=TextAlign.Center);Spacer(Modifier.height(18.dp))
 Column(Modifier.fillMaxWidth().background(Cream,RoundedCornerShape(24.dp)).padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  OutlinedTextField(name,{name=it},label={Text("الاسم")},modifier=Modifier.fillMaxWidth(),singleLine=true)
  Text("الفئة العمرية",fontFamily=Arabic,color=Green);Row(verticalAlignment=Alignment.CenterVertically){listOf("أقل من 18" to "أقل من 18","18 فأكثر" to "18+").forEach{(l,v)->Row(Modifier.weight(1f),verticalAlignment=Alignment.CenterVertically){RadioButton(age==v,{age=v});Text(l,fontFamily=Arabic,color=Ink)}}}
  Text("الجنس",fontFamily=Arabic,color=Green);Row{listOf("ذكر","أنثى").forEach{v->Row(Modifier.weight(1f),verticalAlignment=Alignment.CenterVertically){RadioButton(gender==v,{gender=v});Text(v,fontFamily=Arabic,color=Ink)}}}
  Text("المذهب",fontFamily=Arabic,color=Green);Row{listOf("شيعي","سني").forEach{v->Row(Modifier.weight(1f),verticalAlignment=Alignment.CenterVertically){RadioButton(madhhab==v,{madhhab=v});Text(v,fontFamily=Arabic,color=Ink)}}}
  Text("محافظة السكن",fontFamily=Arabic,color=Green);Box{OutlinedButton(onClick={cityMenu=true},modifier=Modifier.fillMaxWidth()){Text(city,fontFamily=Arabic)};DropdownMenu(cityMenu,{cityMenu=false},modifier=Modifier.heightIn(max=330.dp).background(Cream)){governorates.forEach{DropdownMenuItem(text={Text(it,fontFamily=Arabic)},onClick={city=it;cityMenu=false})}}}
  Button(onClick={onSave(Profile(name.trim().ifBlank{"مستخدم"},age=="18+",gender,madhhab,city))},modifier=Modifier.fillMaxWidth(),enabled=true,colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("حفظ والمتابعة",fontFamily=Arabic,fontSize=20.sp)}
 }
 }
}

@Composable private fun Home(p:Profile,current:Hadith?,total:Int,onNext:()->Unit,onMenu:()->Unit){Column(Modifier.fillMaxSize().background(Green).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("مرحباً ${p.name}",fontFamily=Arabic,color=Color.White,fontSize=17.sp);Spacer(Modifier.height(10.dp));Text("حديث",fontFamily=Arabic,color=Gold,fontSize=43.sp,fontWeight=FontWeight.Bold);Text("من هدي النبوة وأهل البيت",fontFamily=Arabic,color=Color.White.copy(.8f));Spacer(Modifier.height(24.dp));Column(Modifier.fillMaxWidth().weight(1f).background(Green2,RoundedCornerShape(26.dp)).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){if(current==null)Text("اضغط لتظهر لك كلمة من نور",fontFamily=Arabic,color=Gold,fontSize=25.sp,textAlign=TextAlign.Center) else {Text(current.speaker,fontFamily=Arabic,color=Gold,fontSize=19.sp);Spacer(Modifier.height(20.dp));Text(current.text,fontFamily=Arabic,color=Color.White,fontSize=26.sp,lineHeight=42.sp,textAlign=TextAlign.Center);Spacer(Modifier.height(20.dp));Text("المصدر: ${current.source}",fontFamily=Arabic,color=Color.White.copy(.75f),fontSize=12.sp,textAlign=TextAlign.Center)}};Spacer(Modifier.height(18.dp));Button(onClick=onNext,modifier=Modifier.fillMaxWidth().height(56.dp),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Green)){Text("اضغط",fontFamily=Arabic,fontSize=23.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(10.dp));Text("${total} حديثاً متاحاً وفق اختيار المذهب",fontFamily=Arabic,color=Color.White.copy(.7f),fontSize=12.sp);Text("محتوى الفئة العمرية: ${if(p.adult)"عام" else "عناية أكبر بالأخلاق وحسن السلوك"}",fontFamily=Arabic,color=Color.White.copy(.7f),fontSize=12.sp)} }

@Composable private fun HistoryPage(list:List<Hadith>,count:Int,onReset:()->Unit){Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("أحاديثي · $count",fontFamily=Arabic,fontSize=25.sp,color=Green,fontWeight=FontWeight.Bold);TextButton(onClick=onReset){Text("تصفير أحاديثي",fontFamily=Arabic,color=Brown)}};LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(list.reversed()){h->Card(colors=CardDefaults.cardColors(containerColor=Color.White),border=BorderStroke(1.dp,Gold)){Column(Modifier.padding(15.dp)){Text(h.speaker,fontFamily=Arabic,color=Green,fontSize=16.sp);Text(h.text,fontFamily=Arabic,color=Ink,fontSize=20.sp);Text(h.source,fontFamily=Arabic,color=Brown,fontSize=12.sp)}}}}} }

@Composable private fun ThawabPage(onFatiha:()->Unit){Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("ثواب هذا التطبيق إلى روح المرحوم الحاج مهند صالح المحمداوي والشهيد المغدور حيدر صباح الموسوي وأخيه الشهيد السعيد سعد صباح الموسوي",fontFamily=Arabic,color=Brown,fontSize=21.sp,lineHeight=34.sp,textAlign=TextAlign.Center);Spacer(Modifier.height(30.dp));Text("زيارة الموتى وإهداء ثواب التطبيق للشهداء والموتى أجمعين",fontFamily=Arabic,color=Green,fontSize=23.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center);Spacer(Modifier.height(35.dp));IconButton(onClick=onFatiha,modifier=Modifier.size(76.dp).background(Green,RoundedCornerShape(24.dp))){Icon(Icons.Default.MenuBook,"قراءة سورة الفاتحة",tint=Gold,modifier=Modifier.size(42.dp))};Text("اقرأ سورة الفاتحة",fontFamily=Arabic,color=Brown,fontSize=16.sp)} }

@Composable private fun HelpPage(report:String,onReport:(String)->Unit,ctx:android.content.Context){Column(Modifier.fillMaxSize().padding(22.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("مركز المساعدة",fontFamily=Arabic,fontSize=26.sp,color=Green,fontWeight=FontWeight.Bold);Text("اكتب وصف المشكلة أو الخلل الذي واجهته. يتطلب إرسال البلاغ ربط بريدك الإلكتروني.",fontFamily=Arabic,color=Brown,fontSize=16.sp);OutlinedTextField(report,onReport,modifier=Modifier.fillMaxWidth().weight(1f),label={Text("وصف المشكلة")},placeholder={Text("اكتب هنا...")});Button(onClick={val i=Intent(Intent.ACTION_SENDTO).apply{data= Uri.parse("mailto:tatbeeqhadeeth@gmail.com");putExtra(Intent.EXTRA_SUBJECT,"بلاغ من تطبيق حديث");putExtra(Intent.EXTRA_TEXT,report)};try{ctx.startActivity(i)}catch(_:Exception){}},enabled=report.isNotBlank(),modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("إرسال عبر البريد",fontFamily=Arabic,fontSize=19.sp)};Text("البريد المستلم: tatbeeqhadeeth@gmail.com\nحدّ 10 بلاغات شهرياً يحتاج إلى خادم موثوق وتسجيل دخول فعلي، لذلك لم أضع عدّاداً شكلياً غير آمن في التطبيق.",fontFamily=Arabic,color=Brown,fontSize=12.sp,lineHeight=20.sp)} }

@Composable private fun DuasPage(p:Profile){var size by remember{mutableFloatStateOf(23f)};val entries=if(p.madhhab=="شيعي") listOf("دعاء الفرج" to "اللَّهُمَّ كُنْ لِوَلِيِّكَ الحُجَّةِ بْنِ الحَسَنِ صَلَوَاتُكَ عَلَيْهِ وَعَلَى آبَائِهِ...","دعاء قصير" to "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.") else listOf("دعاء قرآني" to "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.","دعاء قرآني" to "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ.");Column(Modifier.fillMaxSize().padding(16.dp)){Text("الأدعية المقدسة",fontFamily=Arabic,color=Green,fontSize=26.sp,fontWeight=FontWeight.Bold);Text("حجم الخط",fontFamily=Arabic,color=Brown);Slider(value=size,onValueChange={size=it},valueRange=18f..34f);LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){items(entries){(title,body)->Card(colors=CardDefaults.cardColors(containerColor=Color.White),border=BorderStroke(1.dp,Gold)){Column(Modifier.padding(16.dp)){Text(title,fontFamily=Arabic,color=Green,fontSize=19.sp);Text(body,fontFamily=Arabic,color=Ink,fontSize=size.sp,lineHeight=(size*1.7f).sp);Text(if(body.startsWith("رَبَّنَا"))"المصدر: القرآن الكريم، البقرة 2:201 أو آل عمران 3:8" else "النص دعاء متداول، ويلزم إكمال توثيقه من مصدر حديثي قبل اعتماده كنص مسند.",fontFamily=Arabic,color=Brown,fontSize=11.sp)}}}}} }

@Composable private fun PrayerPage(p:Profile){var city by remember{mutableStateOf(cities.firstOrNull{it.name.contains(p.governorate)}?:City(p.governorate,"Baghdad"))};var menu by remember{mutableStateOf(false)};var data by remember{mutableStateOf<Map<String,String>>(emptyMap())};var loading by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")};var reload by remember{mutableIntStateOf(0)}
 LaunchedEffect(city,reload){loading=true;error="";try{val date=SimpleDateFormat("dd-MM-yyyy",Locale.US).format(Date());val method=if(p.madhhab=="شيعي") 0 else 3;val url="https://api.aladhan.com/v1/timingsByCity/$date?city=${city.api}&country=Iraq&method=$method";val j=withContext(Dispatchers.IO){val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=12000;c.readTimeout=12000;try{JSONObject(c.inputStream.bufferedReader().use{it.readText()})}finally{c.disconnect()}};val t=j.getJSONObject("data").getJSONObject("timings");data=listOf("Fajr" to "الفجر","Sunrise" to "الشروق","Dhuhr" to "الظهر","Asr" to "العصر","Maghrib" to "المغرب","Isha" to "العشاء").associate{it.second to t.getString(it.first).substringBefore(" ")}}catch(_:Exception){error="تعذّر جلب المواقيت، تحقق من الإنترنت."};loading=false}
 Column(Modifier.fillMaxSize().padding(18.dp)){Text("أوقات الصلاة",fontFamily=Arabic,color=Green,fontSize=27.sp,fontWeight=FontWeight.Bold);Text("المذهب: ${p.madhhab} · الحساب الفلكي عبر AlAdhan",fontFamily=Arabic,color=Brown);Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text("المحافظة: ${city.name}  ▾",fontFamily=Arabic)};DropdownMenu(menu,{menu=false},modifier=Modifier.heightIn(max=350.dp)){cities.forEach{DropdownMenuItem(text={Text(it.name,fontFamily=Arabic)},onClick={city=it;menu=false})}}};Spacer(Modifier.height(15.dp));when{loading->Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()};error.isNotBlank()->Text(error);else->LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(data.toList()){(label,time)->Card(colors=CardDefaults.cardColors(containerColor=Green),border=BorderStroke(1.dp,Gold)){Row(Modifier.fillMaxWidth().padding(18.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(label,fontFamily=Arabic,color=Gold,fontSize=20.sp);Text(time,color=Color.White,fontSize=20.sp)}}}}};TextButton(onClick={reload++}){Text("تحديث المواقيت",fontFamily=Arabic)};Text("تنبيه: هذه مواقيت حسابية أولية وليست اعتماداً رسمياً. راجع تقويم الجهة الدينية المحلية، كما أن ضبط طريقة الحساب الجعفرية بدقة لكل مدينة ما زال بحاجة إلى تدقيق مرجعي.",fontFamily=Arabic,color=Brown,fontSize=12.sp,lineHeight=18.sp)} }

@Composable private fun QuranPage(p:Profile){var surah by remember{mutableIntStateOf(1)};var menu by remember{mutableStateOf(false)};var loading by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")};var verses by remember{mutableStateOf<List<Pair<String,String>>>(emptyList())};var names by remember{mutableStateOf<List<String>>(emptyList())};var tafsirNote by remember{mutableStateOf("")}
 LaunchedEffect(surah){loading=true;error="";try{val j=withContext(Dispatchers.IO){val c=URL("https://api.alquran.cloud/v1/surah/$surah").openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=15000;try{JSONObject(c.inputStream.bufferedReader().use{it.readText()})}finally{c.disconnect()}};val a=j.getJSONObject("data").getJSONArray("ayahs");verses=(0 until a.length()).map{val v=a.getJSONObject(it);v.getString("text") to "القرآن الكريم، سورة ${j.getJSONObject("data").getString("name")}، الآية ${v.getInt("numberInSurah")}"};tafsirNote=if(p.madhhab=="شيعي")"لم أدرج تفسيراً شيعياً غير موثق في هذه النسخة. يلزم اختيار مصدر تفسيري معتمد وتثبيت بياناته قبل عرضه." else "نص القرآن محمّل من AlQuran Cloud. لم أدرج تفسيراً آلياً غير موثق؛ يلزم ربط تفسير معتمد مع توثيق كل آية."}catch(_:Exception){error="تعذّر تحميل السورة. تحقق من الإنترنت."};loading=false}
 LaunchedEffect(Unit){try{val j=withContext(Dispatchers.IO){val c=URL("https://api.alquran.cloud/v1/surah").openConnection() as HttpURLConnection;try{JSONObject(c.inputStream.bufferedReader().use{it.readText()})}finally{c.disconnect()}};val a=j.getJSONArray("data");names=(0 until a.length()).map{a.getJSONObject(it).getString("name")}}catch(_:Exception){}}
 Column(Modifier.fillMaxSize().padding(14.dp)){Text("القرآن الكريم",fontFamily=Arabic,color=Green,fontSize=27.sp,fontWeight=FontWeight.Bold);Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text("${if(names.size>=surah)names[surah-1] else "السورة رقم $surah"}  ▾",fontFamily=Arabic)};DropdownMenu(menu,{menu=false},modifier=Modifier.heightIn(max=400.dp)){(1..114).forEach{n->DropdownMenuItem(text={Text("$n. ${names.getOrNull(n-1)?:"سورة $n"}",fontFamily=Arabic)},onClick={surah=n;menu=false})}}};if(loading)Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center){CircularProgressIndicator()}else if(error.isNotBlank())Text(error)else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){items(verses){(v,ref)->Card(colors=CardDefaults.cardColors(containerColor=Color.White),border=BorderStroke(1.dp,Gold)){Column(Modifier.padding(14.dp)){Text(v,fontFamily=Arabic,color=Ink,fontSize=24.sp,lineHeight=43.sp,textAlign=TextAlign.End);Text(ref,fontFamily=Arabic,color=Brown,fontSize=11.sp)}}}};Text("مصدر النص: AlQuran Cloud API، رواية حفص. التفسير: $tafsirNote",fontFamily=Arabic,color=Brown,fontSize=11.sp,lineHeight=17.sp)} }
