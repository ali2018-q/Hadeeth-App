package com.hadeeth.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val Green = Color(0xFF10251E)
private val Green2 = Color(0xFF1B3A2D)
private val Gold = Color(0xFFD7B875)
private val Cream = Color(0xFFF5F0E5)
private val Ink = Color(0xFF26352D)
private val Muted = Color(0xFFB8C4B9)

data class Hadith(val id: String, val speaker: String, val text: String, val source: String)

private val hadiths = listOf(
    Hadith("p1", "رسول الله صلى الله عليه وآله", "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.", "صحيح البخاري، الحديث 1"),
    Hadith("p2", "رسول الله صلى الله عليه وآله", "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.", "صحيح البخاري، الحديث 13؛ صحيح مسلم، الحديث 45"),
    Hadith("p3", "رسول الله صلى الله عليه وآله", "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.", "صحيح البخاري، الحديث 6018؛ صحيح مسلم، الحديث 47"),
    Hadith("p4", "رسول الله صلى الله عليه وآله", "يسّروا ولا تعسّروا، وبشّروا ولا تنفّروا.", "صحيح البخاري، الحديث 69؛ صحيح مسلم، الحديث 1734"),
    Hadith("a1", "الإمام علي عليه السلام", "قيمة كل امرئ ما يحسنه.", "نهج البلاغة، الحكمة 81"),
    Hadith("a2", "الإمام علي عليه السلام", "الناس أعداء ما جهلوا.", "نهج البلاغة، من الحكم"),
    Hadith("a3", "الإمام علي عليه السلام", "لسان العاقل وراء قلبه، وقلب الأحمق وراء لسانه.", "نهج البلاغة، من الحكم"),
    Hadith("a4", "الإمام علي عليه السلام", "إذا تم العقل نقص الكلام.", "نهج البلاغة، من الحكم")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HadeethApp() }
    }
}

@Composable
fun HadeethApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("hadeeth_data", 0) }
    var page by remember { mutableStateOf("home") }
    var menu by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf<Hadith?>(null) }
    var started by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }
    var dedicated by remember { mutableStateOf(false) }

    fun seenIds(): MutableSet<String> {
        val arr = JSONArray(prefs.getString("seen", "[]") ?: "[]")
        return mutableSetOf<String>().apply { repeat(arr.length()) { add(arr.getString(it)) } }
    }
    fun history(): List<Hadith> {
        val ids = seenIds()
        return hadiths.filter { ids.contains(it.id) }
    }
    fun nextHadith() {
        started = true
        val seen = seenIds()
        val remaining = hadiths.filterNot { seen.contains(it.id) }
        if (remaining.isNotEmpty()) {
            val chosen = remaining.random()
            seen.add(chosen.id)
            val arr = JSONArray()
            seen.forEach { arr.put(it) }
            prefs.edit().putString("seen", arr.toString()).apply()
            current = chosen
        } else current = null
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green2, background = Cream, surface = Cream)) {
        Surface(Modifier.fillMaxSize(), color = Cream) {
            Column(Modifier.fillMaxSize().background(Cream)) {
                Row(
                    Modifier.fillMaxWidth().background(Green).padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (page != "home") {
                        IconButton(onClick = { page = "home" }) {
                            Icon(Icons.Default.ArrowBack, null, tint = Gold)
                        }
                    }
                    Text("حديث", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Default.MoreVert, "القائمة", tint = Gold)
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("أحاديثي") }, onClick = { menu = false; page = "history" })
                            DropdownMenuItem(text = { Text("الدعم") }, onClick = { menu = false; page = "support" })
                            DropdownMenuItem(text = { Text("الثواب") }, onClick = { menu = false; page = "thawab" })
                        }
                    }
                }
                when (page) {
                    "home" -> HomePage(current, started, hadiths.size, ::nextHadith)
                    "history" -> HistoryPage(history())
                    "support" -> SupportPage(report, { report = it }, sent, {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "message/rfc822"
                            putExtra(Intent.EXTRA_SUBJECT, "تقرير مشكلة - تطبيق حديث")
                            putExtra(Intent.EXTRA_TEXT, report)
                        }
                        try { context.startActivity(Intent.createChooser(intent, "إرسال التقرير")) ; sent = true }
                        catch (_: Exception) { sent = false }
                    })
                    "thawab" -> ThawabPage(dedicated) { dedicated = true }
                }
            }
        }
    }
}

@Composable
fun HomePage(current: Hadith?, started: Boolean, total: Int, onPress: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Green).padding(horizontal = 24.dp, vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text("بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيمِ", color = Muted, fontSize = 16.sp)
        if (current == null && started) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("اكتملت الأحاديث المتاحة", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("اطّلعت على جميع الأحاديث الموجودة في هذه النسخة.", color = Muted, textAlign = TextAlign.Center)
            }
        } else if (current != null) {
            Column(
                Modifier.fillMaxWidth().background(Green2, RoundedCornerShape(24.dp)).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(current.speaker, color = Gold, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(22.dp))
                Text(current.text, color = Color.White, fontSize = 23.sp, lineHeight = 38.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(22.dp))
                Text("المصدر: ${current.source}", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("اضغط لتقرأ حديثاً", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("كلمات من نور الهداية", color = Muted, fontSize = 15.sp)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Button(
                onClick = onPress,
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Green),
                shape = RoundedCornerShape(50),
                modifier = Modifier.size(width = 190.dp, height = 66.dp),
                enabled = !(started && current == null)
            ) {
                Text("اضغط", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            Text("كل ضغطة تكشف حديثاً لم يظهر لك من قبل", color = Muted, fontSize = 12.sp)
        }
        Text("نورٌ من هدي النبوّة وبلاغة أمير المؤمنين", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun HistoryPage(history: List<Hadith>) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(
                "عن أبي عبد الله الصادق عليه السلام قال:\n«من حفظ من شيعتنا أربعين حديثاً بعثه الله عز وجل يوم القيامة عالماً فقيهاً ولم يعذبه»",
                color = Green, fontSize = 18.sp, lineHeight = 30.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
            )
            Text("أمالي الصدوق", color = Green2, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = Gold)
            Spacer(Modifier.height(12.dp))
            Text("الأحاديث التي قرأتها", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        if (history.isEmpty()) {
            item { Text("لم تقرأ أي حديث بعد. اضغط على «اضغط» لتبدأ.", color = Ink, modifier = Modifier.padding(12.dp)) }
        }
        items(history.reversed()) { h ->
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(16.dp)) {
                Text(h.speaker, color = Green2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                Text(h.text, color = Ink, fontSize = 18.sp, lineHeight = 29.sp)
                Spacer(Modifier.height(8.dp))
                Text("المصدر: ${h.source}", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SupportPage(report: String, onReport: (String) -> Unit, sent: Boolean, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("مركز المساعدة", color = Green, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("اكتب وصف المشكلة، ثم شارك التقرير عبر تطبيق البريد المتوفر على جهازك.", color = Ink, fontSize = 15.sp, lineHeight = 24.sp)
        OutlinedTextField(value = report, onValueChange = onReport, modifier = Modifier.fillMaxWidth().height(190.dp), label = { Text("وصف المشكلة") }, placeholder = { Text("اشرح لنا ما الذي حدث...") })
        Button(onClick = onSend, enabled = report.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Green2)) {
            Text("إرسال التقرير")
        }
        if (sent) Text("تم فتح تطبيق المشاركة. أكمل الإرسال من التطبيق الذي اخترته.", color = Green2)
        Text("ملاحظة: ربط المحادثة المباشرة بمركز دعم فعلي يحتاج إلى خادم وعنوان دعم رسمي.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ThawabPage(dedicated: Boolean, onDedicate: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("إهداء الثواب", color = Green, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text(
            "اللهم اجعل ثواب ما نقرأه من أحاديث وما نتعلّمه من هدي رسولك وأهل بيته عليهم السلام هديةً إلى أرواح الشهداء وموتى المسلمين والمؤمنين والمؤمنات، وارحمهم برحمتك الواسعة.",
            color = Ink, fontSize = 19.sp, lineHeight = 34.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = onDedicate, colors = ButtonDefaults.buttonColors(containerColor = Green2)) {
            Text(if (dedicated) "تم تسجيل الإهداء" else "إهداء الثواب")
        }
        if (dedicated) {
            Spacer(Modifier.height(12.dp))
            Text("تقبّل الله صالح الأعمال، ورحم الله موتاكم وموتى المؤمنين.", color = Green2, textAlign = TextAlign.Center)
        }
    }
}
