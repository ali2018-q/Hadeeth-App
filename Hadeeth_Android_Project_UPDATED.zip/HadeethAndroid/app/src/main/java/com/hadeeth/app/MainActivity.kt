package com.hadeeth.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF092D22)
private val Green2 = Color(0xFF164735)
private val Green3 = Color(0xFF245B43)
private val Brown = Color(0xFF593B27)
private val Brown2 = Color(0xFF79583B)
private val Gold = Color(0xFFD9B66F)
private val Cream = Color(0xFFF5EEDF)
private val Ink = Color(0xFF2E3028)
private val Muted = Color(0xFFD8D0BD)
private val ArabicDisplay = FontFamily.Serif

data class Hadith(val id: String, val speaker: String, val text: String, val source: String)
data class IraqiCity(val name: String, val apiName: String)

private val iraqiCities = listOf(
    IraqiCity("بغداد", "Baghdad"), IraqiCity("البصرة", "Basra"), IraqiCity("النجف", "Najaf"),
    IraqiCity("كربلاء", "Karbala"), IraqiCity("الموصل", "Mosul"), IraqiCity("أربيل", "Erbil"),
    IraqiCity("السليمانية", "Sulaymaniyah"), IraqiCity("كركوك", "Kirkuk"), IraqiCity("الحلة", "Hillah"),
    IraqiCity("الناصرية", "Nasiriyah"), IraqiCity("العمارة", "Amarah"), IraqiCity("الديوانية", "Diwaniyah"),
    IraqiCity("الرمادي", "Ramadi"), IraqiCity("تكريت", "Tikrit"), IraqiCity("دهوك", "Duhok")
)

private val hadiths = listOf(
    Hadith("p1", "رسول الله صلى الله عليه وآله", "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.", "صحيح البخاري، الحديث 1"),
    Hadith("p2", "رسول الله صلى الله عليه وآله", "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.", "صحيح البخاري، الحديث 13؛ صحيح مسلم، الحديث 45"),
    Hadith("p3", "رسول الله صلى الله عليه وآله", "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.", "صحيح البخاري، الحديث 6018؛ صحيح مسلم، الحديث 47"),
    Hadith("p4", "رسول الله صلى الله عليه وآله", "يسّروا ولا تعسّروا، وبشّروا ولا تنفّروا.", "صحيح البخاري، الحديث 69؛ صحيح مسلم، الحديث 1734"),
    Hadith("a1", "الإمام علي عليه السلام", "قيمة كل امرئ ما يحسنه.", "نهج البلاغة، الحكمة 81"),
    Hadith("a2", "الإمام علي عليه السلام", "الناس أعداء ما جهلوا.", "نهج البلاغة، من الحكم"),
    Hadith("a3", "الإمام علي عليه السلام", "لسان العاقل وراء قلبه، وقلب الأحمق وراء لسانه.", "نهج البلاغة، من الحكم"),
    Hadith("a4", "الإمام علي عليه السلام", "إذا تم العقل نقص الكلام.", "نهج البلاغة، من الحكم")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HadeethApp() }
    }
}

@Composable
fun HadeethApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("hadeeth_data", 0) }
    var page by remember { mutableStateOf("home") }
    var menu by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf<Hadith?>(null) }
    var started by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }
    var dedicated by remember { mutableStateOf(false) }

    fun seenIds(): MutableSet<String> {
        val arr = JSONArray(prefs.getString("seen", "[]") ?: "[]")
        return mutableSetOf<String>().apply { repeat(arr.length()) { add(arr.getString(it)) } }
    }
    fun history(): List<Hadith> { val ids = seenIds(); return hadiths.filter { ids.contains(it.id) } }
    fun nextHadith() {
        started = true
        val seen = seenIds()
        val remaining = hadiths.filterNot { seen.contains(it.id) }
        if (remaining.isNotEmpty()) {
            val chosen = remaining.random(); seen.add(chosen.id)
            val arr = JSONArray(); seen.forEach { arr.put(it) }
            prefs.edit().putString("seen", arr.toString()).apply(); current = chosen
        } else current = null
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green2, background = Cream, surface = Cream, secondary = Gold)) {
        Surface(Modifier.fillMaxSize(), color = Cream) {
            Column(Modifier.fillMaxSize().background(Cream)) {
                Row(
                    Modifier.fillMaxWidth().background(Green).padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (page != "home") IconButton(onClick = { page = if (page == "prayer" || page == "prayerChoice") "home" else "home" }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Gold)
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("حديث", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
                        Text("نورٌ من الهداية", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "القائمة", tint = Gold) }
                        DropdownMenu(
                            expanded = menu, onDismissRequest = { menu = false },
                            modifier = Modifier.background(Cream)
                        ) {
                            MenuRow("أحاديثي", "سجل ما قرأت", Icons.Default.History) { menu = false; page = "history" }
                            MenuRow("أوقات الصلاة", "المواقيت حسب المذهب", Icons.Default.AccessTime) { menu = false; page = "prayerChoice" }
                            MenuRow("الثواب", "إهداء العمل", Icons.Default.Favorite) { menu = false; page = "thawab" }
                            MenuRow("مركز المساعدة", "الدعم والتواصل", Icons.Default.Bookmark) { menu = false; page = "support" }
                        }
                    }
                }
                when (page) {
                    "home" -> HomePage(current, started, hadiths.size, ::nextHadith) { page = "prayerChoice" }
                    "history" -> HistoryPage(history())
                    "support" -> SupportPage(report, { report = it }, sent, {
                        val intent = Intent(Intent.ACTION_SEND).apply { type = "message/rfc822"; putExtra(Intent.EXTRA_SUBJECT, "تقرير مشكلة - تطبيق حديث"); putExtra(Intent.EXTRA_TEXT, report) }
                        try { context.startActivity(Intent.createChooser(intent, "إرسال التقرير")); sent = true } catch (_: Exception) { sent = false }
                    })
                    "thawab" -> ThawabPage(dedicated) { dedicated = true }
                    "prayerChoice" -> PrayerChoicePage { page = "prayer:$it" }
                    else -> if (page.startsWith("prayer:")) PrayerTimesPage(if (page.endsWith("shia")) "شيعي" else "سني")
                }
            }
        }
    }
}

@Composable
private fun MenuRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Column { Text(title, color = Green, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay); Text(subtitle, color = Brown2, fontSize = 11.sp) } },
        leadingIcon = { Icon(icon, null, tint = Brown2) }, onClick = onClick
    )
}

@Composable
fun HomePage(current: Hadith?, started: Boolean, total: Int, onPress: () -> Unit, onPrayer: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Green).padding(horizontal = 22.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيمِ", color = Muted, fontSize = 16.sp, fontFamily = ArabicDisplay)
        Spacer(Modifier.height(20.dp))
        Text("حديث", color = Gold, fontSize = 46.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
        Text("مِنْ هَدْيِ النُّبُوَّةِ وَبَلَاغَةِ أَمِيرِ الْمُؤْمِنِينَ", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        if (current == null && started) {
            Text("اكتملت الأحاديث المتاحة", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
            Text("اطّلعت على جميع الأحاديث الموجودة في هذه النسخة.", color = Muted, textAlign = TextAlign.Center)
        } else if (current != null) {
            Column(Modifier.fillMaxWidth().weight(1f).background(Green2, RoundedCornerShape(26.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(current.speaker, color = Gold, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, fontFamily = ArabicDisplay)
                Spacer(Modifier.height(20.dp)); Text(current.text, color = Color.White, fontSize = 24.sp, lineHeight = 39.sp, textAlign = TextAlign.Center, fontFamily = ArabicDisplay)
                Spacer(Modifier.height(20.dp)); Text("المصدر: ${current.source}", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else {
            Column(Modifier.fillMaxWidth().weight(1f).background(Brown.copy(alpha = .22f), RoundedCornerShape(26.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("كلماتٌ من نور الهداية", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
                Spacer(Modifier.height(10.dp)); Text("تأمّل، وتعلّم، وازدد قرباً من الكلمة الطيبة", color = Muted, fontSize = 15.sp, textAlign = TextAlign.Center, fontFamily = ArabicDisplay)
            }
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = onPress, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Green), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(58.dp), enabled = !(started && current == null)) {
            Text("اقرأ حديثاً", fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onPrayer, border = BorderStroke(1.dp, Gold), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Default.AccessTime, null); Spacer(Modifier.width(8.dp)); Text("أوقات الصلاة", fontSize = 18.sp, fontFamily = ArabicDisplay)
        }
        Spacer(Modifier.height(14.dp)); Text("كل ضغطة تكشف حديثاً لم يظهر لك من قبل", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun PrayerChoicePage(onChoose: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Cream).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("أوقات الصلاة", color = Green, fontSize = 30.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
        Spacer(Modifier.height(10.dp)); Text("اختر طريقة عرض المواقيت", color = Brown2, fontSize = 16.sp, fontFamily = ArabicDisplay)
        Spacer(Modifier.height(30.dp))
        listOf("shia" to "المذهب الجعفري (شيعي)", "sunni" to "المذهب السني").forEach { (key, label) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable { onChoose(key) }, colors = CardDefaults.cardColors(containerColor = Green), border = BorderStroke(1.dp, Gold), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccessTime, null, tint = Gold, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(16.dp))
                    Text(label, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
                }
            }
        }
    }
}

@Composable
fun PrayerTimesPage(madhab: String) {
    var city by remember { mutableStateOf(iraqiCities.first()) }
    var cityMenu by remember { mutableStateOf(false) }
    var times by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }

    LaunchedEffect(city, madhab, refresh) {
        loading = true; error = ""; times = emptyMap()
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val url = if (madhab == "شيعي") {
                "https://api.aladhan.com/v1/timingsByCity/$date?city=${city.apiName}&country=Iraq&method=0"
            } else {
                "https://api.aladhan.com/v1/timingsByCity/$date?city=${city.apiName}&country=Iraq&method=99&methodSettings=18,null,17&school=0&tune=0,0,0,5,3,3,0,0,0"
            }
            val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 12000; connection.readTimeout = 12000; connection.requestMethod = "GET"
                try { JSONObject(connection.inputStream.bufferedReader().use { it.readText() }) } finally { connection.disconnect() }
            }
            val data = result.getJSONObject("data")
            val obj = data.getJSONObject("timings")
            times = listOf("Fajr" to "الفجر", "Sunrise" to "الشروق", "Dhuhr" to "الظهر", "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء").associate { (key, label) -> label to obj.getString(key).substringBefore(" ") }
        } catch (e: Exception) { error = "تعذّر جلب المواقيت. تأكد من اتصال الإنترنت ثم أعد المحاولة." }
        loading = false
    }

    Column(Modifier.fillMaxSize().background(Cream).padding(18.dp)) {
        Text("مواقيت الصلاة", color = Green, fontSize = 27.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
        Text("الحساب: $madhab  •  العراق", color = Brown2, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Box {
            OutlinedButton(onClick = { cityMenu = true }, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Brown2), colors = ButtonDefaults.outlinedButtonColors(contentColor = Green)) {
                Text("المدينة: ${city.name}   ▾", fontSize = 17.sp, fontFamily = ArabicDisplay)
            }
            DropdownMenu(expanded = cityMenu, onDismissRequest = { cityMenu = false }, modifier = Modifier.heightIn(max = 360.dp).background(Cream)) {
                iraqiCities.forEach { c -> DropdownMenuItem(text = { Text(c.name, color = Green) }, onClick = { city = c; cityMenu = false }) }
            }
        }
        Spacer(Modifier.height(18.dp))
        if (loading) Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green2) }
        else if (error.isNotEmpty()) Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(error, color = Brown, textAlign = TextAlign.Center); Spacer(Modifier.height(12.dp)); Button(onClick = { refresh++ }, colors = ButtonDefaults.buttonColors(containerColor = Green2)) { Text("إعادة المحاولة") }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(times.entries.toList()) { entry ->
                    Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Gold)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(entry.key, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
                            Text(entry.value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        Text(if (madhab == "سني") "طريقة حساب تقريبية مضبوطة على إعدادات مستخدمة للعراق؛ يُستحسن مطابقتها مع تقويم الوقف السني المحلي." else "المواقيت محسوبة وفق طريقة الشيعة الاثني عشرية (قم) عبر خدمة الحساب الفلكي.", color = Brown2, fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun HistoryPage(history: List<Hadith>) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("عن أبي عبد الله الصادق عليه السلام قال:\n«من حفظ من شيعتنا أربعين حديثاً بعثه الله عز وجل يوم القيامة عالماً فقيهاً ولم يعذبه»", color = Green, fontSize = 18.sp, lineHeight = 30.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), fontFamily = ArabicDisplay)
            Text("أمالي الصدوق", color = Green2, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp)); HorizontalDivider(color = Gold); Spacer(Modifier.height(12.dp))
            Text("الأحاديث التي قرأتها", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
        }
        if (history.isEmpty()) item { Text("لم تقرأ أي حديث بعد. اضغط على «اقرأ حديثاً» لتبدأ.", color = Ink, modifier = Modifier.padding(12.dp)) }
        items(history.reversed()) { h ->
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(16.dp)) {
                Text(h.speaker, color = Green2, fontWeight = FontWeight.Bold, fontSize = 14.sp); Spacer(Modifier.height(8.dp))
                Text(h.text, color = Ink, fontSize = 18.sp, lineHeight = 29.sp, fontFamily = ArabicDisplay); Spacer(Modifier.height(8.dp)); Text("المصدر: ${h.source}", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SupportPage(report: String, onReport: (String) -> Unit, sent: Boolean, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("مركز المساعدة", color = Green, fontSize = 23.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
        Text("اكتب وصف المشكلة، ثم شارك التقرير عبر تطبيق البريد المتوفر على جهازك.", color = Ink, fontSize = 15.sp, lineHeight = 24.sp)
        OutlinedTextField(value = report, onValueChange = onReport, modifier = Modifier.fillMaxWidth().height(190.dp), label = { Text("وصف المشكلة") }, placeholder = { Text("اشرح لنا ما الذي حدث...") })
        Button(onClick = onSend, enabled = report.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Green2)) { Text("إرسال التقرير") }
        if (sent) Text("تم فتح تطبيق المشاركة. أكمل الإرسال من التطبيق الذي اخترته.", color = Green2)
        Text("ملاحظة: ربط المحادثة المباشرة بمركز دعم فعلي يحتاج إلى خادم وعنوان دعم رسمي.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ThawabPage(dedicated: Boolean, onDedicate: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Cream).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("ثواب هذا التطبيق إلى روح المرحوم الحاج أبو الحسين مهند صالح المحمداوي", color = Brown, fontSize = 24.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, fontFamily = ArabicDisplay)
        Spacer(Modifier.height(26.dp))
        Text("إهداء الثواب", color = Green, fontSize = 26.sp, fontWeight = FontWeight.Bold, fontFamily = ArabicDisplay)
        Spacer(Modifier.height(24.dp))
        Text("اللهم اجعل ثواب ما نقرأه من أحاديث وما نتعلّمه من هدي رسولك وأهل بيته عليهم السلام هديةً إلى أرواح الشهداء وموتى المسلمين والمؤمنين والمؤمنات، وارحمهم برحمتك الواسعة.", color = Ink, fontSize = 19.sp, lineHeight = 34.sp, textAlign = TextAlign.Center, fontFamily = ArabicDisplay)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onDedicate, colors = ButtonDefaults.buttonColors(containerColor = Green2), shape = RoundedCornerShape(16.dp)) { Text(if (dedicated) "تم تسجيل الإهداء" else "إهداء الثواب", fontFamily = ArabicDisplay) }
        if (dedicated) { Spacer(Modifier.height(12.dp)); Text("تقبّل الله صالح الأعمال، ورحم الله موتاكم وموتى المؤمنين.", color = Green2, textAlign = TextAlign.Center) }
    }
}
